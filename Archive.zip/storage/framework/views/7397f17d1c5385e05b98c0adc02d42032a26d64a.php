<?php $__env->startSection('content'); ?>

    <app-services _nghost-qyg-c52="">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div _ngcontent-qyg-c52="" class="services-img align-content-center row services-img p-0 m-0">
            <div _ngcontent-qyg-c52="" class="col-12 animate__animated animate__backInDown">
                <a href="/personal">
                    <button _ngcontent-qyg-c52=""
                    type="button" routerlink="/personal" class="btn btn-danger mb-3 ml-40 w-160-px" tabindex="0"
                    ng-reflect-router-link="/personal" >Personalni 1 na 1</button>
                </a>
            </div>
            <div _ngcontent-qyg-c52="" class="col-12 animate__animated animate__backInDown">
                <a href="/#online-coaching">
                    <button _ngcontent-qyg-c52=""
                        type="button" class="btn btn-danger mb-3 ml-40 w-160-px">Online coaching</button>
                </a>
            </div>
            <div _ngcontent-qyg-c52="" class="col-12 animate__animated animate__backInDown">
                <a href="/#nutrition-coaching">
                    <button _ngcontent-qyg-c52=""
                        type="button" class="btn btn-danger mb-3 ml-40 w-160-px">Nutrition coaching</button>
                </a>
            </div>
        </div>

        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </app-services>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/pages/services.blade.php ENDPATH**/ ?>