<img src="/images/logo.jpeg" width="40" alt="dale fitness" />
<?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/components/application-logo.blade.php ENDPATH**/ ?>