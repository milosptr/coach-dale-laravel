<?php $__env->startSection('content'); ?>

<app-home _nghost-ngf-c48="">

    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <base _ngcontent-ngf-c48="" href="https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/">
    <div _ngcontent-ngf-c48="" id="slider">
        <figure _ngcontent-ngf-c48=""><img _ngcontent-ngf-c48="" src="https://sreten-angular.vercel.app/assets/slider1.jpg"
                alt=""><img _ngcontent-ngf-c48="" src="https://sreten-angular.vercel.app/assets/slider2.jpg" alt=""><img
                _ngcontent-ngf-c48="" src="https://sreten-angular.vercel.app/assets/slider3.jpg" alt=""><img
                _ngcontent-ngf-c48="" src="https://sreten-angular.vercel.app/assets/slider1.jpg" alt=""><img
                _ngcontent-ngf-c48="" src="https://sreten-angular.vercel.app/assets/slider2.jpg" alt=""></figure>
    </div>
    <div _ngcontent-ngf-c48="" class="row g-0 justify-content-center align-items-center">
        <div _ngcontent-ngf-c48="" class="col-md-6 col-12 text-center animate__animated animate__backInDown">
            <p _ngcontent-ngf-c48="" class="text-grey fs-4 text-uppercase">Dobrodosli</p>
            <p _ngcontent-ngf-c48="" class="text-grey-white fs-1 text-uppercase">Dragutin Mrdak</p>
            <p _ngcontent-ngf-c48="" class="fs-6">FITNES TRENER</p>
        </div>
        <div _ngcontent-ngf-c48="" class="col-md-5 col-12 pr-4 mb-5 mt-4 animate__animated animate__backInUp">
            <p _ngcontent-ngf-c48="" class="line-height font-weight-bold">Ukoliko si u potrazi za personalnim
                trenerom radi postizanja najboljih rezultata na pravom si mjestu, 8 godina personalnih treninga
                i 5 godina CrossFit grupnih treninga mi je dao mnogo razlicitih profila i vjezbaca razlicitih
                nivoa kao i izazova sto mi je pomoglo u kreiranju vise programa treninga koji te mogu dovesti do
                cilja.</p><br _ngcontent-ngf-c48="">
            <p _ngcontent-ngf-c48="" class="line-height font-weight-light">Moj fokus je prvenstveno na zdravlje
                i dugorocnost u fitnesu/sportu kao i edukaciji klijenata, pa je i pristup svakom klijentu
                individualizovan. Neke od mojih treninga sa klijentima mozete vidjeti na instagramu kao i
                recepte koji dobijate u planu ishrane.</p>
        </div>
    </div>
    <div _ngcontent-ngf-c48="" class="container-white">
        <div _ngcontent-ngf-c48="" class="container">
            <div _ngcontent-ngf-c48="" class="col-12 text-center">
                <h6 _ngcontent-ngf-c48="" class="pt-4 color-red">ŽELJENI REZULTATI NADOMAK RUKE</h6>
                <h2 _ngcontent-ngf-c48="" class="pb-5 color-red">SAZNAJ VIŠE</h2>
            </div>
            <div _ngcontent-ngf-c48="" class="text-center mb-5"><iframe _ngcontent-ngf-c48="" width="70%" height="450"
                    src="https://www.youtube.com/embed/fcN37TxBE_s" title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen=""></iframe></div>
        </div>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</app-home>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/pages/index.blade.php ENDPATH**/ ?>