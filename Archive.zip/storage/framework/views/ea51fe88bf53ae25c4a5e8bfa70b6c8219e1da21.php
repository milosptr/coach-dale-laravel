<?php $__env->startSection('content'); ?>

    <div>

        <?php echo $__env->make('web.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="contakt-background">

            <div class="col-12 text-center p-3 mt-2">
                <h1 class="mt-4 text-3xl"><?php echo e(__('pages.contact_title')); ?></h1>
            </div>

            
            <div class="container">
                <div class="row p-0 m-0">
                    <?php $__currentLoopData = range(0,9); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-4">
                        <div id="accordion" class="mt-4">
                          <div class="question">
                            <div id="heading-<?php echo e($loop->iteration); ?>">
                              <h5 class="mb-0">
                                <button data-toggle="collapse" data-target="#collapse-<?php echo e($loop->iteration); ?>" aria-expanded="true" aria-controls="collapse-<?php echo e($loop->iteration); ?>" class="btn col-12 p-0 color-withe">
                                  <?php $question = "pages.faq_".$loop->iteration."_title"; ?>
                                  <?php echo e(__($question)); ?>

                                </button>
                              </h5>
                            </div>
                            <div id="collapse-<?php echo e($loop->iteration); ?>" aria-labelledby="heading-<?php echo e($loop->iteration); ?>" data-parent="#accordion" class="collapse">
                              <div class="card-body">
                                <?php $answer = "pages.faq_".$loop->iteration."_answer"; ?>
                                <?php echo e(__($answer)); ?>

                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            

            
            <section id="contact" class="contact py-5">
                
                <div class="container">
                    
                    <div class="row contakt-box p-3">

                        
                        <div class="col-md-6">

                            <div class="col-md-12 mb-2">
                                <h3 class="text-xl font-bold mb-2"><?php echo e(__('pages.say_hello')); ?>​</h3>
                                <p class="mb-10">
                                    <?php echo e(__('pages.say_hello_info')); ?>

                                </p>
                            </div>

                            <div class="address">
                                <h5><?php echo e(__('pages.address_title')); ?>:</h5>
                                <ul class="list-unstyled">
                                    <li>
                                        <i class="fas fa-map-marker-alt"></i>
                                        Beograd, Srbija
                                    </li>
                                </ul>
                            </div>

                            <div class="email">
                                <h5><?php echo e(__('pages.email_title')); ?>:</h5>
                                <ul class="list-unstyled">
                                    <li>
                                        <i class="fas fa-envelope"></i>
                                        mrdak.dragutin@gmail.com
                                    </li>
                                </ul>
                            </div>

                            <div class="phone">
                                <h5><?php echo e(__('pages.phone_title')); ?>:</h5>
                                <ul class="list-unstyled">
                                    <li>
                                        <i class="fas fa-phone"></i>
                                        066 226 586
                                    </li>
                                </ul>
                            </div>
                        </div>

                        
                        <div class="col-md-6">

                            <div>

                                
                                <div class="card-body">
                                    
                                    <form novalidate="" class="ng-untouched ng-pristine ng-valid">

                                        <div class="form-row row">

                                            <div class="form-group col-md-6">
                                                <input id="Full Name" name="Full Name"
                                                    placeholder="<?php echo e(__('pages.your_name')); ?>" type="text"
                                                    class="form-control mb-md-0 mb-3">
                                            </div>

                                            <div class="form-group col-md-6">
                                                <input type="email" id="inputEmail4"
                                                    placeholder="<?php echo e(__('pages.your_email')); ?>" class="form-control">
                                            </div>

                                        </div>

                                        <div class="form-row mt-4">

                                            <div class="form-group col-md-12">
                                                <textarea id="comment" name="comment"
                                                    cols="40" rows="5" placeholder="<?php echo e(__('pages.your_message')); ?>"
                                                    class="form-control"></textarea>
                                            </div>

                                        </div>

                                        <div class="form-row mt-4 text-center">
                                            <button type="button" class="btn btn-danger">
                                                <?php echo e(__('pages.send')); ?> <i class="fas fa-paper-plane"></i>
                                            </button>
                                        </div>

                                    </form>
                                    

                                </div>
                                

                            </div>
                        </div>

                    </div>
                    

                
                </div>

            </section>
            

        </div>
        

        <div class="mt-2">
            <?php echo $__env->make('web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/web/contact.blade.php ENDPATH**/ ?>