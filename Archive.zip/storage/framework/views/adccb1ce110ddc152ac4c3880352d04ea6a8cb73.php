<?php $__env->startSection('content'); ?>

    <div>

        <?php echo $__env->make('web.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <h1 class="text-center mt-5 mb-4 fs-1"><?php echo e(__('pages.about_h1')); ?></h1>

        
        <div class="container mt-md-5 mb-md-5 mt-2 mb-2">
            
            <div class="row font-13-px">
                
                <div class="col-md-7 col-12 animate__animated animate__backInDown">

                    <p>
                        <?php echo e(__('pages.about_p1')); ?>

                    </p>

                    <br>

                    <p>
                        <?php echo e(__('pages.about_p2')); ?>

                    </p>

                    <br>

                    <p>
                        <?php echo e(__('pages.about_p3')); ?>

                    </p>

                    <br>

                    <p>

                        <?php echo e(__('pages.about_p4')); ?>

                    </p>

                    <br>

                    <p>
                        <?php echo e(__('pages.about_p5')); ?>


                    </p>

                </div>
                

                <div class="col-md-5 col-12">
                    <img src="/images/dragutin-mrdak.jpg" alt="Dragutin Mrdak" class="w-full mt-5 animate__animated animate__backInDown " style="min-width: 155%!important; margin-left: -70%; top: -60px ; z-index: -1; position: relative;">
                </div>
                

            </div>
            

            
            <div class="row mt-5 font-13-px">

                
                <div class="col-md-6 col-12">
                    <img src="https://sreten-angular.vercel.app/assets/crossfit.jpg" alt="Crossfit" class="w-100 mt-5 mb-md-0 mb-2 animate__animated animate__backInDown box-shadow">
                </div>
                

                
                <div class="mt-10 col-md-6 col-12 animate__animated animate__backInDown">

                    <h5 class="fs-4 mb-4"><?php echo e(__('pages.about_h5')); ?> </h5>

                    <p>
                        <?php echo e(__('pages.about_p6' )); ?>

                    </p>

                    <br>

                    <p>
                        <?php echo e(__('pages.about_p7' )); ?>


                    </p>

                    <br>

                    <p>
                      <?php echo __('pages.about_p8'); ?>

                    </p>

                    <br>

                    <p>
                      <?php echo __('pages.about_p9'); ?>


                    </p>
                </div>
                
            </div>
            

        </div>

        <?php echo $__env->make('web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/web/about.blade.php ENDPATH**/ ?>