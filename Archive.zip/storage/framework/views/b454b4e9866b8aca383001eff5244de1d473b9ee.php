<app-header _ngcontent-ngf-c48="" _nghost-ngf-c45="">
    <nav _ngcontent-ngf-c45="" class="navbar navbar-expand-lg navbar-light bg-light pt-3 pb-3">
        <div _ngcontent-ngf-c45="" class="container-fluid"><img _ngcontent-ngf-c45=""
                src="https://sreten-angular.vercel.app/assets/logo.jpg" alt="Dragutin Mrdak"
                class="w-60-logo"><button _ngcontent-ngf-c45="" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                aria-label="Toggle navigation" class="navbar-toggler"><span _ngcontent-ngf-c45=""
                    class="navbar-toggler-icon"></span></button>
            <div _ngcontent-ngf-c45="" id="navbarNavAltMarkup"
                class="collapse navbar-collapse text-uppercase font-14-px">
                <div _ngcontent-ngf-c45="" class="navbar-nav"><a _ngcontent-ngf-c45="" aria-current="page"
                        routerlink="/home" class="nav-link" ng-reflect-router-link="/home"
                        href="/home">Pocetna</a><a _ngcontent-ngf-c45="" routerlink="/about" class="nav-link"
                        ng-reflect-router-link="/about" href="/about">O meni</a><a _ngcontent-ngf-c45=""
                        routerlink="/services" class="nav-link" ng-reflect-router-link="/services"
                        href="/services">Usluge</a><a _ngcontent-ngf-c45="" routerlink="/contact" class="nav-link"
                        ng-reflect-router-link="/contact" href="/contact">Kontakt</a><a _ngcontent-ngf-c45=""
                        routerlink="/login" class="nav-link position-absolute-right border-red text-uppercase"
                        ng-reflect-router-link="/login" href="/login">Uloguj se <i _ngcontent-ngf-c45=""
                            class="fas fa-sign-in-alt"></i></a><a _ngcontent-ngf-c45="" routerlink="/registration"
                        class="nav-link position-absolute-right-5 border-red text-uppercase"
                        ng-reflect-router-link="/registration" href="/registration"><i _ngcontent-ngf-c45=""
                            class="fas fa-user"></i> Registracija</a></div>
            </div>
        </div>
    </nav>
</app-header>
<?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/includes/header.blade.php ENDPATH**/ ?>