<app-footer _ngcontent-ngf-c48="" _nghost-ngf-c46="">
    <div _ngcontent-ngf-c46="" class="row g-0 justify-content-evenly p-md-0 p-4">
        <div _ngcontent-ngf-c46="" class="col-md-3 col-12 mt-md-5 mt-2"><img _ngcontent-ngf-c46=""
                src="https://sreten-angular.vercel.app/assets/logo.jpg" alt="Dragutin Mrdak" class="w-60-logo ml-2 border-radius">
            <p _ngcontent-ngf-c46="" class="mt-2 font-11-px">TRENIRAJ KAKO TI SE KAŽE, JEDI KAKO TI SE KAŽE
                I <br _ngcontent-ngf-c46=""> GLEDAĆEŠ PROMENE KOJE SI ODUVEK ŽELEO DA VIDIŠ</p>
        </div>
        <div _ngcontent-ngf-c46="" class="col-md-3 col-12 mt-md-5 mt-2">
            <h5 _ngcontent-ngf-c46="" class="mb-4">Kontakt Podaci</h5><span
                _ngcontent-ngf-c46=""><i _ngcontent-ngf-c46="" class="fas fa-envelope"></i> Email:
                mrdak.dragutin@gmail.com</span><br _ngcontent-ngf-c46=""><span _ngcontent-ngf-c46=""><i
                    _ngcontent-ngf-c46="" class="fas fa-phone"></i> Telefon: 063/ 87 - 09 - 090</span><br
                _ngcontent-ngf-c46=""><span _ngcontent-ngf-c46=""><i _ngcontent-ngf-c46=""
                    class="fas fa-map-marker-alt"></i> Lokacija: Beograd, Srbija</span>
        </div>
        <div _ngcontent-ngf-c46="" class="col-md-3 col-12 mt-md-5 mt-2 footer">
            <h5 _ngcontent-ngf-c46="" class="mb-4">Drustvene Mreze</h5><span _ngcontent-ngf-c46=""
                class="icon-border"><i _ngcontent-ngf-c46="" class="fab fa-facebook-square"></i></span><a
                _ngcontent-ngf-c46="" href="https://www.instagram.com/dale_5_fitness/?hl=sr"
                target="_blank"><span _ngcontent-ngf-c46="" class="icon-border"><i _ngcontent-ngf-c46=""
                        class="fab fa-instagram mr-2"></i></span></a><a _ngcontent-ngf-c46=""
                href="https://msng.link/o/?0638709090=vi"><span _ngcontent-ngf-c46=""
                    class="icon-border"><i _ngcontent-ngf-c46=""
                        class="fab fa-viber mr-2"></i></span></a><a _ngcontent-ngf-c46=""
                href="https://msng.link/o/?0638709090=wa"><span _ngcontent-ngf-c46=""
                    class="icon-border"><i _ngcontent-ngf-c46=""
                        class="fab fa-whatsapp mr-2"></i></span></a>
        </div>
    </div>
    <div _ngcontent-ngf-c46="" class="footer-white col-12 text-center p-1 mt-5">
        <p _ngcontent-ngf-c46="" class="mb-0"><i _ngcontent-ngf-c46=""
                class="far fa-registered mr-2"></i><b _ngcontent-ngf-c46="">Sva prava zadrzava Dragutin
                Mrdak.</b></p>
    </div>
</app-footer>
<?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/includes/footer.blade.php ENDPATH**/ ?>