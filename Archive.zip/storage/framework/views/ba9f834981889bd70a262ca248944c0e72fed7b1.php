<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Table')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg flex">
                <div class="w-1/3 p-6 mb-1 border-r border-gray-200 overflow-scroll flex-1">
                    <div class="py-2 border-b border-gray-200">
                      <div class="font-bold text-3xl">Users</div>
                    </div>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="/admin/progress/?user=<?php echo e($user->id); ?>" class="block py-2 my-2 <?php echo e(isset($_GET['user']) && $_GET['user'] == $user->id ? 'bg-indigo-600 text-white' : 'bg-gray-100'); ?> rounded-lg px-5">
                        <div class="font-bold"><?php echo e($user->name); ?></div>
                        <div class="text-xs"><?php echo e($user->email); ?></div>
                      </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="w-2/3 p-6 bg-white">
                  <?php if(isset($_GET['user'])): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($user->id == $_GET['user']): ?>
                      <div class="grid grid-cols-4 gap-8">
                          <?php $__currentLoopData = $user->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="w-48 h-48">
                              <div class="h-full bg-center bg-cover bg-no-repeat" style="background-image: url('/<?php echo e($image->file_path); ?>')"></div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <div class="py-32 font-bold text-3xl text-center">Select user</div>
                  <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/milospetrovic/Sites/coach-dale/resources/views/admin/progress.blade.php ENDPATH**/ ?>