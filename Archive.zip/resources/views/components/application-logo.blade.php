<img src="/images/logo.jpeg" width="40" alt="dale fitness" />
