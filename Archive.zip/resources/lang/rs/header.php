<?php

return [
  'home' => 'Početna',
  'about' => 'O meni',
  'services' => 'Usluge',
  'contact' => 'Kontakt',
  'log_in' => 'Uloguj se',
  'sign_up' => 'Napravi nalog'
];
