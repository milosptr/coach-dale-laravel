<?php

return [
  'home' => 'Home',
  'about' => 'About me',
  'services' => 'Services',
  'contact' => 'Contact',
  'log_in' => 'Login in',
  'sign_up' => 'Sign up'
];
