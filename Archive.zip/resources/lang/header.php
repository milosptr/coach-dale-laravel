<?php

return [
  'home' => 'Početna',
  'about' => 'O meni',
  'services' => 'Usluge',
  'contact' => 'Kontakt',
  'login' => 'Uloguj se',
  'signup' => 'Napravi nalog'
];
